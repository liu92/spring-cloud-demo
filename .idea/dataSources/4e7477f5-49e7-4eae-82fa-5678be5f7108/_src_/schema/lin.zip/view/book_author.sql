CREATE VIEW book_author AS
  SELECT
    `b`.`id`              AS `id`,
    `b`.`author_id`       AS `author_id`,
    `b`.`book_name`       AS `book_name`,
    `b`.`book_number`     AS `book_number`,
    `b`.`publish_company` AS `publish_company`,
    `a`.`id`              AS `a_id`,
    `a`.`author_name`     AS `author_name`
  FROM (`lin`.`book` `b` LEFT JOIN `lin`.`author` `a` ON ((`b`.`author_id` = `a`.`id`)));
